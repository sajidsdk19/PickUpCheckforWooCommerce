<?php
/**
 * Plugin Name:       Stroopwafel Oman - Remove Delivery Charges on Self Pickup
 * Description:       Removes the "Delivery Charges" fee row from checkout when user selects "I’ll pick it up myself" (billing_delivery = Option_2). Works on runtime with AJAX.
 * Version:           1.0.0
 * Author:            Your Name / Grok Assisted
 * Text Domain:       stroopwafel-oman
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * 1. Server-side: Prevent the Delivery Charges fee when "I’ll pick it up myself" is selected
 */
add_action('woocommerce_cart_calculate_fees', 'stroopwafel_conditional_delivery_fee');

function stroopwafel_conditional_delivery_fee()
{
    if (is_admin() && !defined('DOING_AJAX')) {
        return;
    }

    // Get the custom billing_delivery field value from posted data or session
    $delivery_option = WC()->checkout()->get_value('billing_delivery')
        ?? (isset($_POST['billing_delivery']) ? sanitize_text_field($_POST['billing_delivery']) : '');

    // If user selected "I’ll pick it up myself" (Option_2), do NOT add the fee
    if ($delivery_option === 'Option_2') {
        return;
    }

    // Otherwise add the Delivery Charges fee (adjust amount if needed)
    WC()->cart->add_fee(__('Delivery Charges', 'stroopwafel-oman'), 2.00);
}

/**
 * 2. Make the custom field trigger checkout update on change (important for runtime switching)
 */
add_action('woocommerce_after_checkout_form', 'stroopwafel_trigger_update_on_delivery_change');

function stroopwafel_trigger_update_on_delivery_change()
{
?>
    <script type="text/javascript">
    jQuery(function($) {
        // Trigger update_checkout whenever billing_delivery changes
        $(document.body).on('change', '#billing_delivery', function() {
            $('body').trigger('update_checkout');
        });
    });
    </script>
    <?php
}

/**
 * 3. Client-side: Hide the "Delivery Charges" row instantly when Option_2 is selected
 *     (for better UX - instant feedback before AJAX finishes)
 */
add_action('woocommerce_after_checkout_form', 'stroopwafel_hide_delivery_fee_js');

function stroopwafel_hide_delivery_fee_js()
{
?>
    <script type="text/javascript">
    jQuery(function($) {
        function toggleDeliveryFeeRow() {
            const $row = $('.shop_table tfoot tr.fee th:contains("Delivery Charges")').closest('tr');
            
            if ($('#billing_delivery').val() === 'Option_2') {
                $row.hide();   // Hide instantly
            } else {
                $row.show();   // Show when "Deliver to address" is selected
            }
        }

        // Run on page load
        toggleDeliveryFeeRow();

        // Run every time the field changes + after WooCommerce updates the order review
        $(document.body).on('change', '#billing_delivery', toggleDeliveryFeeRow);
        $(document.body).on('updated_checkout', toggleDeliveryFeeRow);
    });
    </script>
    <?php
}